const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://mongo:27017/financeDB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

const transactionSchema = new mongoose.Schema({
  title: String,
  amount: Number
});

const Transaction = mongoose.model("Transaction", transactionSchema);

app.get("/transactions", async (req, res) => {
  const data = await Transaction.find();
  res.json(data);
});

app.post("/transactions", async (req, res) => {
  const newTransaction = new Transaction(req.body);
  await newTransaction.save();
  res.json(newTransaction);
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});