import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [transactions, setTransactions] = useState([]);
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("");

  const fetchTransactions = async () => {
    const res = await axios.get("http://localhost:5000/transactions");
    setTransactions(res.data);
  };

  const addTransaction = async () => {
    await axios.post("http://localhost:5000/transactions", {
      title,
      amount
    });
    fetchTransactions();
  };

  useEffect(() => {
    fetchTransactions();
  }, []);

  return (
    <div>
      <h1>Personal Finance Tracker</h1>
      <input placeholder="Title" onChange={(e) => setTitle(e.target.value)} />
      <input placeholder="Amount" onChange={(e) => setAmount(e.target.value)} />
      <button onClick={addTransaction}>Add</button>

      <ul>
        {transactions.map((t, index) => (
          <li key={index}>{t.title} - ₹{t.amount}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;